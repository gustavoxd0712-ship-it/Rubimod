# Rubi Mod (Forge 1.12.2)

Añade **mena de rubí**, **rubí** y **bloque de rubí**.
- La mena solo se puede picar con pico de **diamante** o mejor.
- Aparece en el Overworld entre las alturas Y 5 y 24 (rareza ajustable en `RubyWorldGen.java`).
- Fortuna y Toque de seda funcionan. Da 3-7 de experiencia.
- Recetas: 9 rubíes = 1 bloque; 1 bloque = 9 rubíes.

## Compilar
Usa RetroFuturaGradle 2.0.3 (Java 25 + Gradle 9.7.0 para ejecutar Gradle; el mod se compila con Java 8).

    gradle build

El .jar queda en `build/libs/`. Tambien funciona en GitHub Actions (ver `.github/workflows/build.yml`).

Para regenerar las texturas: `python3 tools/gen_textures.py` (necesita Pillow).
