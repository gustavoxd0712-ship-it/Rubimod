import random, os
from PIL import Image

OUT = "src/main/resources/assets/rubimod/textures"
os.makedirs(OUT + "/blocks", exist_ok=True)
os.makedirs(OUT + "/items", exist_ok=True)

H = (255, 150, 168)   # brillo
L = (240, 62, 92)     # claro
M = (206, 22, 58)     # medio
D = (140, 8, 40)      # oscuro
PAL = {"H": H, "L": L, "M": M, "D": D}

def stone(seed):
    rnd = random.Random(seed)
    cells = [[rnd.randint(-9, 9) for _ in range(8)] for _ in range(8)]
    img = Image.new("RGBA", (16, 16))
    for y in range(16):
        for x in range(16):
            v = 122 + cells[y // 2][x // 2] + rnd.randint(-6, 6)
            if rnd.random() < 0.06: v -= 22   # grietas
            if rnd.random() < 0.05: v += 16   # motas claras
            v = max(60, min(170, v))
            img.putpixel((x, y), (v, v, v + 2, 255))
    return img

CLUSTERS = [
    (1, 1, [".HL.", "HLMM", "LMMD", ".MDD"]),
    (9, 1, ["HLM", "LMD", "MDD"]),
    (6, 6, [".LL.", "HLMM", "LMMD", ".DDD"]),
    (12, 8, [".HL", "LMM", "MDD"]),
    (2, 10, ["HL.", "LMM", ".MD"]),
    (11, 13, ["HL", "MD"]),
]

def ruby_ore():
    img = stone(7)
    px = img.load()
    cover, halo = set(), set()
    for ox, oy, rows in CLUSTERS:
        for j, row in enumerate(rows):
            for i, ch in enumerate(row):
                if ch != ".":
                    cover.add((ox + i, oy + j))
    for (x, y) in cover:
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1)):
            n = (x + dx, y + dy)
            if n not in cover and 0 <= n[0] < 16 and 0 <= n[1] < 16:
                halo.add(n)
    for (x, y) in halo:
        r, g, b, a = px[x, y]
        px[x, y] = (int(r * .68), int(g * .68), int(b * .68), 255)
    for ox, oy, rows in CLUSTERS:
        for j, row in enumerate(rows):
            for i, ch in enumerate(row):
                if ch in PAL:
                    px[ox + i, oy + j] = PAL[ch] + (255,)
    px[1, 2] = (255, 225, 230, 255)   # destello
    px[6, 7] = (255, 225, 230, 255)
    return img

def ruby_block():
    img = Image.new("RGBA", (16, 16))
    px = img.load()
    rnd = random.Random(3)
    c = 7.5
    for y in range(16):
        for x in range(16):
            dx, dy = x - c, y - c
            r = max(abs(dx), abs(dy))
            # faceta segun el triangulo
            if abs(dy) >= abs(dx):
                facet = 0 if dy < 0 else 3
            else:
                facet = 1 if dx < 0 else 2
            base = [(236, 58, 88), (222, 36, 70), (190, 16, 50), (150, 8, 40)][facet]
            # capas concentricas: el centro brilla, el borde se oscurece
            layer = 1.18 if r < 2.6 else (1.0 if r < 5.6 else 0.86)
            col = [min(255, int(v * layer)) for v in base]
            if r in (2.5, 5.5, 3.5, 6.5) and False: pass
            n = rnd.randint(-5, 5)
            col = [max(0, min(255, v + n)) for v in col]
            px[x, y] = tuple(col) + (255,)
    # lineas de union entre capas
    for y in range(16):
        for x in range(16):
            dx, dy = x - c, y - c
            r = max(abs(dx), abs(dy))
            if r in (2.5, 5.5):
                R, G, B, A = px[x, y]
                px[x, y] = (int(R * .8), int(G * .8), int(B * .85), 255)
    # borde biselado
    for i in range(16):
        for (x, y, k) in ((i, 0, 1.12), (0, i, 1.08), (i, 15, .6), (15, i, .65)):
            R, G, B, A = px[x, y]
            px[x, y] = (min(255, int(R * k)), min(255, int(G * k)), min(255, int(B * k)), 255)
    for (x, y) in ((3, 3), (12, 4), (4, 12), (8, 7)):
        px[x, y] = (255, 205, 215, 255)
    return img

GEM = [
    "................",
    "................",
    "................",
    "....OOOOOOOO....",
    "...OHWHLLLMMO...",
    "..OHHHLLLLMMDO..",
    ".OHHHLLLLLMMMDO.",
    ".OHHLLLLLMMMDDO.",
    "..OHLLLLMMMDDO..",
    "...OLLLLMMDDO...",
    "....OLMMMDDO....",
    ".....OMMMDO.....",
    "......OMDO......",
    ".......OO.......",
    "................",
    "................",
]
GPAL = {"O": (88, 0, 26), "H": (255, 168, 184), "W": (255, 238, 240),
        "L": L, "M": M, "D": D}

def ruby_item():
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    for y, row in enumerate(GEM):
        assert len(row) == 16, (y, len(row))
        for x, ch in enumerate(row):
            if ch in GPAL:
                img.putpixel((x, y), GPAL[ch] + (255,))
    # lineas de faceta interiores
    for x in range(4, 12):
        r, g, b, a = img.getpixel((x, 7))
        img.putpixel((x, 7), (int(r * .85), int(g * .8), int(b * .85), 255))
    return img

ruby_ore().save(OUT + "/blocks/ruby_ore.png")
ruby_block().save(OUT + "/blocks/ruby_block.png")
ruby_item().save(OUT + "/items/ruby.png")

# vista previa ampliada
sheet = Image.new("RGBA", (16 * 3 * 10 + 40, 16 * 10 + 20), (60, 60, 70, 255))
for k, p in enumerate(("/blocks/ruby_ore.png", "/blocks/ruby_block.png", "/items/ruby.png")):
    im = Image.open(OUT + p).resize((160, 160), Image.NEAREST)
    sheet.paste(im, (10 + k * 170, 10), im)
sheet.save("/home/claude/preview.png")
print("ok")
